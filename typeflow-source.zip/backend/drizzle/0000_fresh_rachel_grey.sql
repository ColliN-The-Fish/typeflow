CREATE TABLE `runs` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text,
	`day` text NOT NULL,
	`lang` text NOT NULL,
	`article_id` text NOT NULL,
	`version` text NOT NULL,
	`title` text NOT NULL,
	`target` text NOT NULL,
	`created_at` integer NOT NULL,
	`started_at` integer,
	`expires_at` integer NOT NULL,
	`finished_at` integer,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `runs_user_time` ON `runs` (`user_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `scores` (
	`id` text PRIMARY KEY NOT NULL,
	`run_id` text NOT NULL,
	`user_id` text,
	`day` text NOT NULL,
	`lang` text NOT NULL,
	`article_id` text NOT NULL,
	`version` text NOT NULL,
	`wpm` real NOT NULL,
	`raw` real NOT NULL,
	`acc` real NOT NULL,
	`seconds` real NOT NULL,
	`characters` integer NOT NULL,
	`attempts` integer NOT NULL,
	`good` integer NOT NULL,
	`qualified` integer NOT NULL,
	`reason` text,
	`created_at` integer NOT NULL,
	FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `score_run` ON `scores` (`run_id`);--> statement-breakpoint
CREATE INDEX `daily_scores` ON `scores` (`day`,`lang`,`version`,`qualified`);--> statement-breakpoint
CREATE INDEX `scores_user` ON `scores` (`user_id`,`day`);--> statement-breakpoint
CREATE TABLE `users` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`name_key` text NOT NULL,
	`token_hash` text NOT NULL,
	`created_at` integer NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `user_name_key` ON `users` (`name_key`);--> statement-breakpoint
CREATE UNIQUE INDEX `user_token_hash` ON `users` (`token_hash`);