import {sqliteTable,text,integer,real,index,uniqueIndex} from 'drizzle-orm/sqlite-core';
export const users=sqliteTable('users',{
 id:text('id').primaryKey(),name:text('name').notNull(),nameKey:text('name_key').notNull(),tokenHash:text('token_hash').notNull(),createdAt:integer('created_at').notNull(),updatedAt:integer('updated_at').notNull()
},t=>[uniqueIndex('user_name_key').on(t.nameKey),uniqueIndex('user_token_hash').on(t.tokenHash)]);
export const runs=sqliteTable('runs',{
 id:text('id').primaryKey(),userId:text('user_id').references(()=>users.id),day:text('day').notNull(),lang:text('lang').notNull(),articleId:text('article_id').notNull(),version:text('version').notNull(),title:text('title').notNull(),target:text('target').notNull(),createdAt:integer('created_at').notNull(),startedAt:integer('started_at'),expiresAt:integer('expires_at').notNull(),finishedAt:integer('finished_at')
},t=>[index('runs_user_time').on(t.userId,t.createdAt)]);
export const scores=sqliteTable('scores',{
 id:text('id').primaryKey(),runId:text('run_id').notNull(),userId:text('user_id').references(()=>users.id),day:text('day').notNull(),lang:text('lang').notNull(),articleId:text('article_id').notNull(),version:text('version').notNull(),wpm:real('wpm').notNull(),raw:real('raw').notNull(),acc:real('acc').notNull(),seconds:real('seconds').notNull(),characters:integer('characters').notNull(),attempts:integer('attempts').notNull(),good:integer('good').notNull(),qualified:integer('qualified').notNull(),reason:text('reason'),createdAt:integer('created_at').notNull()
},t=>[uniqueIndex('score_run').on(t.runId),index('daily_scores').on(t.day,t.lang,t.version,t.qualified),index('scores_user').on(t.userId,t.day)]);
