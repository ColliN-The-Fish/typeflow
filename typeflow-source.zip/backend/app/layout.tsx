import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TypeFlow · 字流",
  description: "文章输入练习、输入法学堂与每日联网挑战。",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
