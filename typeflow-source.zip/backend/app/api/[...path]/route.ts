import {env} from 'cloudflare:workers';
import {handleApi} from '../../../lib/api.mjs';
export const dynamic='force-dynamic';
export function GET(request:Request){return handleApi(request,env.DB);}
export function POST(request:Request){return handleApi(request,env.DB);}
export function PATCH(request:Request){return handleApi(request,env.DB);}
export function DELETE(request:Request){return handleApi(request,env.DB);}
export function OPTIONS(request:Request){return handleApi(request,env.DB);}
